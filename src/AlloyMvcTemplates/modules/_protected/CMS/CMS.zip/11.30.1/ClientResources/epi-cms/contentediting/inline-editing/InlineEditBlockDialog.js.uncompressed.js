define("epi-cms/contentediting/inline-editing/InlineEditBlockDialog", [
    "dojo/_base/declare",
    "epi/shell/widget/dialog/Dialog",
    "epi/i18n!epi/cms/nls/episerver.shared.action",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons"
], function (
    declare,
    Dialog,
    actionRes,
    resources
) {
    return declare([Dialog], {
        // summary:
        //      Dialog used to display inline edit form

        // saveLabel: [public] String
        //      Label for saving form
        saveLabel: actionRes.save,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.dialogClass = "epi-dialog-portrait inline-edit-dialog";

            var containerNode = document.createElement("div");
            this.content = containerNode;
            this.contentClass = "epi-wrapped epi-mediaSelector";
        },

        getActions: function () {
            var actions = this.inherited(arguments);

            var saveButton = actions[0];
            saveButton.label = this.saveLabel;

            this._publishButtonName = "publish";
            var publishButton = {
                name: this._publishButtonName,
                label: resources.publish.label,
                title: null,
                settings: {
                    "class": "epi-success publish-button"
                },
                action: function () {
                    this.onPublish();
                }.bind(this)
            };
            actions.push(publishButton);

            return actions;
        },

        hideSaveButton: function () {
            this.definitionConsumer.setItemProperty(this._okButtonName, "class", "dijitHidden");
        },

        toggleDisabledSaveButton: function (shouldDisable) {
            this.definitionConsumer.setItemProperty(this._okButtonName, "disabled", shouldDisable ? "disabled" : "");
        },

        togglePublishButton: function (visible) {
            if (visible) {
                this.definitionConsumer.setItemProperty(this._publishButtonName, "class", "epi-success publish-button");
            } else {
                this.definitionConsumer.setItemProperty(this._publishButtonName, "class", "dijitHidden");
            }
        },

        toggleDisabledPublishButton: function (shouldDisable) {
            this.definitionConsumer.setItemProperty(this._publishButtonName, "disabled", shouldDisable ? "disabled" : "");
        },

        _setCloseTextAttr: function (label) {
            this.definitionConsumer.setItemProperty(this._cancelButtonName, "label", label);
        },

        onPublish: function () {
        }
    });
});
