//>>built
define("dojo/cldr/nls/en-ca/currency",{"CAD_symbol":"$","USD_symbol":"US$"});