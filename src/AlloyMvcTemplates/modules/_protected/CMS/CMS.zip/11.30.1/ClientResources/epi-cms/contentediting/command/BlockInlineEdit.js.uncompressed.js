define("epi-cms/contentediting/command/BlockInlineEdit", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/topic",
    "dojo/when",
    //EPi
    "epi",
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/DestroyableByKey",

    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/ContentActionSupport",
    "epi/shell/command/_Command",

    "epi-cms/contentediting/inline-editing/InlineEditBlockDialog",
    "epi-cms/contentediting/inline-editing/BlockEditFormContainer",
    "epi-cms/contentediting/command/BlockInlinePublish",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.inlineediting"
],

function (
    declare,
    lang,
    on,
    topic,
    when,

    epi,
    dependency,
    TypeDescriptorManager,
    DestroyableByKey,

    ContentReference,
    ContentActionSupport,
    _Command,

    InlineEditBlockDialog,
    BlockEditFormContainer,
    InlinePublish,
    resources
) {

    return declare([_Command, DestroyableByKey], {
        // summary:
        //      Inline-edit command for the Block component
        // tags:
        //      internal xproduct

        label: resources.inlineblockedit,

        iconClass: "epi-iconPenQuick",

        // summary:
        //      List of statuses, of which content cannot be edit
        ignoredEditStatuses: [
            ContentActionSupport.versionStatus.CheckedIn,
            ContentActionSupport.versionStatus.DelayedPublish,
            ContentActionSupport.versionStatus.AwaitingApproval
        ],

        postscript: function () {
            this.inherited(arguments);

            this._contentLightStore = dependency.resolve("epi.storeregistry").get("epi.cms.content.light");
            this.own(topic.subscribe("/epi/cms/content/statuschange/", function (status, contentIdentity) {
                if (!this.model || !this.model.contentLink) {
                    return;
                }
                var updatedContentId = new ContentReference(contentIdentity.id).id;
                var currentModelId = new ContentReference(this.model.contentLink).id;
                if (updatedContentId === currentModelId) {
                    this._contentLightStore.refresh(currentModelId).then(function (contentData) {
                        this._refreshContentSettings(contentData);
                    }.bind(this));
                }
            }.bind(this)));
        },

        _execute: function () {
            // summary:
            //    Open the inline edit block dialog
            // tags:
            //      protected

            var dialog = new InlineEditBlockDialog({
                title: this.model.name
            });

            var _this = this;
            var inlinePublishCommand = new InlinePublish({
                commandType: "inline-edit-form"
            });
            var form;

            function updatePublishCommandVisibility() {
                if (!dialog) {
                    return;
                }

                dialog.togglePublishButton(_this.get("hasPublishAccessRights") && !_this.get("isPartOfActiveApproval"));
                dialog.toggleDisabledPublishButton(!(inlinePublishCommand.canPublish() || form.get("isDirty")));
                dialog.toggleDisabledSaveButton(!form.get("isDirty"));
            }

            var isAvailableHandle = inlinePublishCommand.watch("isAvailable", updatePublishCommandVisibility.bind(this));
            var canExecuteHandle = inlinePublishCommand.watch("canExecute", updatePublishCommandVisibility.bind(this));

            form = new BlockEditFormContainer({
                isInlineCreateEnabled: this.isInlineCreateEnabled
            }, dialog.content, "last");
            form.set("contentLink", this.model.contentLink).then(function (formContentData) {
                inlinePublishCommand.set("model", this.model);
                inlinePublishCommand._onModelChange();
                updatePublishCommandVisibility();
                _this.set("isPartOfActiveApproval", formContentData.isPartOfActiveApproval);
            }.bind(this));

            var formCreatedHandle = on(form, "FormCreated", function () {
                if (form.model && !form._model.canChangeContent()) {
                    dialog.hideSaveButton();
                    dialog.set("closeText", "Close");
                }

                dialog.show();
                updatePublishCommandVisibility();

            }.bind(this));

            var onChangeHandle = on(form, "isDirty", updatePublishCommandVisibility.bind(form));

            var executeHandle = on(dialog, "execute", form.saveForm.bind(form));

            var publishHandle = on(dialog, "Publish", function () {
                if (!this.validate()) {
                    return;
                }
                inlinePublishCommand.tryToSaveAndPublish(form).then(function () {
                    dialog.hide();
                });
            });

            var closeHandle = on(dialog, "hide", function () {
                form.destroy();
                inlinePublishCommand.destroy();
                executeHandle.remove();
                closeHandle.remove();
                formCreatedHandle.remove();
                onChangeHandle.remove();
                publishHandle.remove();
                isAvailableHandle.remove();
                canExecuteHandle.remove();
            });
        },

        _getContentData: function () {
            // summary:
            //      Try to get full contentData object
            //      Fetch it from store unless already available
            // tags:
            //      protected

            var contentData = this.model.content || this.model;
            if (!contentData.properties) {
                // need to fetch contentData if statusIndicator feature is turned off
                contentData = this._contentLightStore.get(contentData.contentLink);
            }
            return contentData;
        },

        _onModelChange: function () {
            // summary:
            //      Updates isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            if (this.model instanceof Array) {
                // this command should be available only if one item selected
                // because it should be disabled when multiple blocks are selected
                // like in Assets pane
                if (this.model.length === 1) {
                    this.model = this.model[0];
                } else {
                    this.model = null;
                }
            }

            if (!this.model) {
                this.set("canExecute", false);
                return;
            }

            if (!TypeDescriptorManager.isBaseTypeIdentifier(this.model.typeIdentifier, "episerver.core.blockdata")) {
                this.set("isAvailable", false);
                return;
            }

            this.set("isAvailable", true);

            when(this._getContentData()).then(function (contentData) {
                this._refreshContentSettings(contentData);
            }.bind(this));
        },

        _refreshContentSettings: function (contentData) {
            // summary:
            //      Update the content settings
            // tags:
            //      protected

            var hasAccessRights = ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Edit);
            var hasProviderSupportForEditing = ContentActionSupport.hasProviderCapability(contentData.providerCapabilityMask, ContentActionSupport.providerCapabilities.Edit);
            var isDeleted = contentData.isDeleted;
            var canExecute = (this.ignoredEditStatuses.indexOf(contentData.status) === -1) && hasAccessRights && hasProviderSupportForEditing && !isDeleted;
            this.set("canExecute", canExecute);
            this.set("hasPublishAccessRights", ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Publish));
        }
    });
});
